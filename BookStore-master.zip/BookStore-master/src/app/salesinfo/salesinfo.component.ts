import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salesinfo',
  templateUrl: './salesinfo.component.html',
  styleUrls: ['./salesinfo.component.css']
})
export class SalesinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
